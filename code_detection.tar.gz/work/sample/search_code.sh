#!/bin/bash
#Author: nsdc118

sandbox_prefix='sandbox_'
sandbox_suffix=`md5sum search_code.sh | awk '{print $1}'`
sandbox=$sandbox_prefix$sandbox_suffix

prefix='./'
slash='/'
counter=0

mkdir $sandbox

for i in `find . -name "*.tar.gz"`
do
mkdir $prefix$sandbox$slash$counter
tar zxf $i -C $prefix$sandbox$slash$counter
	for j in `find $prefix$sandbox$slash$counter -type f`
	do
	strings $j >> $j.innertxt
	echo "########## SEARCHING CODE IN $i$j ###########"
	#Searching ADA code
	grep --color '^with' $j.innertxt
	grep --color '^use' $j.innertxt
	grep 'is' $j.innertxt | grep --color 'procedure'
	grep 'is' $j.innertxt | grep 'return' | grep --color 'function'
	grep --color 'begin$' $j.innertxt
	grep --color 'end' $j.innertxt | grep ';'
	#Searching C code
	grep --color '^#include' $j.innertxt
	grep --color 'main()' $j.innertxt
	#Searching JAVA code
	grep 'public' $j.innertxt | grep --color 'class'
	grep 'private' $j.innertxt | grep --color 'class'
	grep 'protected' $j.innertxt | grep --color 'class'
	grep --color 'class ' $j.innertxt
	grep --color 'public static void main(String\[\] args)' $j.innertxt
	grep --color 'public static void main( String\[\] args )' $j.innertxt
	grep --color 'public static void main(String\[\] args )' $j.innertxt
	grep --color 'public static void main( String\[\] args)' $j.innertxt
	grep --color 'public static void main' $j.innertxt
	grep --color '^import ' $j.innertxt
	#Searching simple structures of all languages
	grep --color 'for(' $j.innertxt
	grep --color 'for (' $j.innertxt
	grep --color 'while(' $j.innertxt
	grep --color 'while (' $j.innertxt
	grep --color 'switch(' $j.innertxt
	grep --color 'switch (' $j.innertxt
	grep --color 'if(' $j.innertxt
	grep --color 'if ' $j.innertxt
	grep --color 'else' $j.innertxt
	grep --color 'case' $j.innertxt
	grep --color 'return ' $j.innertxt | grep ';'
	grep --color 'int ' $j.innertxt
	grep --color 'float ' $j.innertxt
	grep --color 'double ' $j.innertxt
	grep --color 'String ' $j.innertxt
	grep --color 'struct' $j.innertxt
	done
((counter++))
done

rm -rf $sandbox

